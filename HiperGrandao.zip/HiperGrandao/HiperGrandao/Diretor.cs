﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HiperGrandao
{
    class Diretor
    {
    }
}
